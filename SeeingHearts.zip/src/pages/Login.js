import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View, ScrollView, Image} from 'react-native';
import css from '../css/style';

import TabHelper from '../helper/TabHelper';

export default class Login extends Component {
  render() {
    return (
		<TabHelper />
	);
  }
}

