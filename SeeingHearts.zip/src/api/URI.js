let urls = {
	Login: "http://www.seeinghearts.com/wp-json/dashboard/users/v1/login",
	Register: "http://www.seeinghearts.com/wp-json/dashboard/users/v1/register",
	AllPosts: "http://www.seeinghearts.com/wp-json/dashboard/gallery/v1/All",
	MyPosts: "http://www.seeinghearts.com/wp-json/dashboard/gallery/v1/My",
	BoldtPosts: "http://www.seeinghearts.com/wp-json/dashboard/gallery/v1/Boldt",
	OtherPosts: "http://www.seeinghearts.com/wp-json/dashboard/gallery/v1/Other",
	SearchPosts: "http://www.seeinghearts.com/wp-json/dashboard/gallery/v1/Search",
}

module.exports = urls;